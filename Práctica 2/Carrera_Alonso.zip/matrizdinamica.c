/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   matrizdinamica.c
 * Author: Xiana
 *
 * Created on 10 de febrero de 2020, 19:18
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */

/*Se vuelve a definir el tipo de datos que contiene la matriz*/
typedef float TELEMENTO;

/*Implementación del TAD matrizD */
typedef struct {
    TELEMENTO *datos;   /*valores de la matriz*/
    short nfilas,ncols; /*tamaño de la matriz (filas, columnas)*/
}STMATRIZ;              /*definición del tipo de datos estructura*/
typedef STMATRIZ *matrizD; /*puntero a estructura*/

/*Funciones de manipulación de datos */
/*Función crear: asigna memoria y devuelve la asignación a la matriz*/
void crear(matrizD *m1, short tamf, short tamc)
{
    short i;
    
    if (tamf <= 0 || tamc <= 0){
        *m1 = NULL;
        printf("El número de filas y el de columnas deben ser positivos\n");
    }
    else{
        *m1=(matrizD)malloc(sizeof(STMATRIZ));
        if (*m1){
            (*m1)->datos=(TELEMENTO*)malloc(tamf*tamc*sizeof(TELEMENTO));
            (*m1)->nfilas=tamf; (*m1)->ncols=tamc;
            for(i=1; i <= tamf*tamc; i++)
                /*Inicialización a 0 de las componentes de la matriz*/
                *((*m1)->datos+i-1) = 0;
        }
        else 
            printf("Error en la reserva de memoria para la matriz\n");
    }
}

/*Función asignar: Asigna un valor a una posición de la matriz */
void asignar(matrizD *m1, short fila, short columna, TELEMENTO valor){
    *((*m1)->datos + (fila-1)*(*m1)->ncols + columna-1)=valor;
}

/*Función liberar: Libera la memoria ocupada por la matriz*/
void liberar(matrizD *m1)
{
    if(*m1){    //Comprobación de que la matriz haya sido creada correctamente.
        if ((*m1)->datos){
            free((*m1)->datos);
            (*m1)->datos = NULL;
        }
        free(*m1);
        *m1 = NULL;
    }    
}

/* Función recuperar: Devuelve el valor que se encuentra en la posición seleccionada*/ 
TELEMENTO recuperar(matrizD m1, short fila, short columna)
{
    TELEMENTO valor;
    
    if (m1){
        if ((fila <= 0 || fila > m1->nfilas) || (columna <= 0 || columna > m1->ncols)) {
            printf("El elemento elegido no existe\n");
            return 0;
        }
        
        valor = *((m1->datos) + (fila-1) * (m1->ncols) + (columna-1));
        return valor;
    }
    
    return 0;
}

/* Función prodescalar: multiplica la matriz por un escalar*/
matrizD prodescalar(matrizD m1, float esc)
{
    matrizD aux = NULL;
    int i, j;
    
    if (m1){
        crear(&aux, m1->nfilas, m1->ncols);
        if (aux) 
            for (i=0; i < m1->nfilas; i++)
                for (j=0; j < m1->ncols; j++)
                    *((aux->datos) + i * (aux->ncols) + j) = *((m1->datos) + i * (m1->ncols) + j) * esc;
    } else
        printf("La matriz no existe\n");
    
    return aux;
}

/* Función nfilas: devuelve el número de filas de la matriz*/
short nfilas(matrizD m1)
{
    if (m1)
        return m1->nfilas;
    else
        return 0;
}

/* Función ncolumnas: devuelve el número de columnas de la matriz*/
short ncolumnas(matrizD m1)
{
    if (m1)
        return m1->ncols;
    else
        return 0;
}