/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.c
 * Author: Xiana Carrera
 *
 * Created on 10 de febrero de 2020, 19:24
 * Este programa permite utilizar el TAD matrizD.
 */

#include <stdio.h>
#include <stdlib.h>
#include "matrizdinamica.h"

/*
 * 
 */

void imprimir(matrizD m1);

int main(int argc, char** argv) {
    matrizD m1 = NULL, aux = NULL;  /* declaramos la matriz y una 
                                     * matriz auxiliar */
    short nfil, ncol, i, j;      /*variables tamaño y recorrido */
    TELEMENTO valor;            /*El valor a introducir en la matriz*/
    float esc;                  /*escalar para la función producto escalar*/                  
    char opcion;                /*La variable del menú*/
    
    if (argc > 3 && argc == atoi(argv[1]) * atoi(argv[2]) + 3) {
        nfil = atoi(argv[1]);
        ncol = atoi(argv[2]);
        crear(&m1, nfil, ncol);
        for (i=1; i<=nfil; i++)
            for (j=1; j<=ncol; j++)
                asignar(&m1, i, j, atof(argv[(i-1)*ncol + (j-1) + 3]));
        imprimir(m1);
    } else if (argc > 1){
        printf("Número de argumentos incorrecto.");
    } else
        printf("No hay argumentos pasados por línea de comandos.");
    
    do {
        printf("\n--------------------\n");
        printf("\na) Crear matriz m1");
        printf("\nb) Destruir matriz m1");
        printf("\nc) Producto por un escalar");
        printf("\nd) Imprimir matriz m1");
        printf("\ns) Salir");
        printf("\n--------------------\n");
        printf("\nOpcion: ");
        scanf(" %c",&opcion);
        switch(opcion) {
            case 'a':   /*Crear matriz m1*/
                liberar(&m1);
                printf("Tamanho de la matriz m1 (filas columnas): ");
                scanf("%hd %hd", &nfil,&ncol);
                crear(&m1, nfil, ncol);
                /*Asignar valores a m1*/
                for (i=1; i<=nfil; i++) {
                    for (j=1; j<=ncol; j++) {
                        printf("m1(%hd,%hd): ", i, j);
                        scanf("%f",&valor);
                        asignar(&m1, i, j, valor);
                    }
                }
                imprimir(m1);
                break;
            case 'b':
                liberar(&m1);
                printf("Matriz eliminada correctamente.");
                break;
            case 'c':
                printf("Introduzca el escalar: ");
                scanf("%f", &esc);
                aux = prodescalar(m1, esc);
                if (aux){
                    imprimir(aux);
                    liberar(&aux);
                }
                break;
            case 'd':
                imprimir(m1);
                break;
            case 's':
                printf ("Saliendo del programa\n");
                break;
            default: printf ("Opcion incorrecta\n");
        }
    } while (opcion != 's');
    
    return (EXIT_SUCCESS);
}

void imprimir(matrizD m1)
{
    short i, j, a, b;
    
    if (m1){
        a = nfilas(m1);
        b = ncolumnas(m1);
        for (i=1; i<=a; i++){ 
            for (j=1; j<=b; j++)
                printf("%f ", recuperar(m1, i, j));
            printf("\n");
        }
        printf("\n");
    } else
        printf("La matriz a imprimir no existe\n");
}