
typedef int TIPOELEMENTOCOLA;
typedef void *TCOLA;

void ColaVacia (TCOLA  *q);
int EsColaVacia (TCOLA  q);
void PrimeroCola (TCOLA  q , TIPOELEMENTOCOLA *e);
void EliminarCola (TCOLA *q);
void AnadirCola (TCOLA *q, TIPOELEMENTOCOLA e);

 